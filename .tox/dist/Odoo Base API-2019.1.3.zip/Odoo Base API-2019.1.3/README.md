# odoo-external-api
An Abstract Base Class to inherit from and interact with Odoos external XML-RPC API
